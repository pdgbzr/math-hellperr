﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bolnica
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        public static string? prichina, kom, psihiatr, narkolog, nevrolog, hirurg;
        public void add_data()
        {
            
            SqliteCommand command = new SqliteCommand();
            Form1.connection.Open();
            command.Connection = Form1.connection;
            if (Form5.idz == 0)
            {
               
            }
     
            
          

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            add_data();
            this.Close();
            Form5 form5 = new Form5();
            form5.Show();
            
         
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
  
        }
    }
}

﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bolnica
{
    public partial class Form2 : Form
    {
        Form1 form1;
        public Form2(Form1 owner)
        {
            form1 = owner;
            InitializeComponent();
        }
        public static string? id, terapevt, oftalmolog, psihiatr, narkolog, nevrolog, hirurg;

        private void fiobox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar == 39)
            {
                e.Handled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (fiobox.Text == "" || numbox.Text == "" || numbox.Text == "+  (   )    -  -" ||snilsbox.Text == "   -   -   -" ||polbox.Text==""||omsbox.Text== "               ")
            {
                MessageBox.Show
               (
               " Заполните все данные перед добавлением.",
               "Сообщение",
               MessageBoxButtons.OK,
               MessageBoxIcon.Information,
               MessageBoxDefaultButton.Button1
               ); ;

            }
            else{
                Form1.fio = fiobox.Text.ToString();
                Form1.dofb = datebirthbox.Text.ToString();
                Form1.num = numbox.Text.ToString();
                Form1.gen = polbox.Text.ToString();
                Form1.snils = snilsbox.Text.ToString();
                Form1.oms = omsbox.Text.ToString();
                SqliteCommand command = new SqliteCommand();
                command.Connection = Form1.connection;
                form1.add_data();
                this.Close();
            }
            
        }

        

   
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Form1.connection.Open();
                SqliteCommand command = new SqliteCommand();
                command.Connection = Form1.connection;
                command.CommandText = "SELECT Терапевт FROM vrachi where ID =" + Form1.idpolzovatelya;
                terapevt = command.ExecuteScalar().ToString();
                command.CommandText = "SELECT Офтальмолог FROM vrachi where ID =" + Form1.idpolzovatelya;
                oftalmolog = command.ExecuteScalar().ToString();
                command.CommandText = "SELECT Психиатр FROM vrachi where ID =" + Form1.idpolzovatelya;
                psihiatr = command.ExecuteScalar().ToString();
                command.CommandText = "SELECT Нарколог FROM vrachi where ID =" + Form1.idpolzovatelya;
                narkolog = command.ExecuteScalar().ToString();
                command.CommandText = "SELECT Невролог FROM vrachi where ID =" + Form1.idpolzovatelya;
                nevrolog = command.ExecuteScalar().ToString();
                command.CommandText = "SELECT Хирург FROM vrachi where ID =" + Form1.idpolzovatelya;
                hirurg = command.ExecuteScalar().ToString();
                Form4 f4 = new Form4();
                f4.Show();
            }
            catch
            {
                MessageBox.Show
          (
          "Сначала сохраните данные пациента.",
          "Сообщение",
          MessageBoxButtons.OK,
          MessageBoxIcon.Information,
          MessageBoxDefaultButton.Button1
          ); ;
            }
        }
    }
}

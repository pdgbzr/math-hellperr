﻿namespace bolnica
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.fiobox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.polbox = new System.Windows.Forms.ComboBox();
            this.datebirthbox = new System.Windows.Forms.MaskedTextBox();
            this.numbox = new System.Windows.Forms.MaskedTextBox();
            this.snilsbox = new System.Windows.Forms.MaskedTextBox();
            this.omsbox = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(143, 313);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(463, 60);
            this.button1.TabIndex = 1;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // fiobox
            // 
            this.fiobox.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fiobox.Location = new System.Drawing.Point(222, 25);
            this.fiobox.Name = "fiobox";
            this.fiobox.Size = new System.Drawing.Size(463, 36);
            this.fiobox.TabIndex = 15;
            this.fiobox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fiobox_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(143, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 30);
            this.label1.TabIndex = 16;
            this.label1.Text = "ФИО";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(46, 156);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 30);
            this.label2.TabIndex = 17;
            this.label2.Text = "Дата рождения";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(31, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(185, 30);
            this.label3.TabIndex = 18;
            this.label3.Text = "Номер телефона";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(151, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 30);
            this.label4.TabIndex = 19;
            this.label4.Text = "Пол";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(78, 243);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 30);
            this.label7.TabIndex = 21;
            this.label7.Text = "Полис ОМС";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(120, 112);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 30);
            this.label8.TabIndex = 20;
            this.label8.Text = "СНИЛС";
            // 
            // polbox
            // 
            this.polbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.polbox.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.polbox.FormattingEnabled = true;
            this.polbox.Items.AddRange(new object[] {
            "Мужской",
            "Женский"});
            this.polbox.Location = new System.Drawing.Point(222, 200);
            this.polbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.polbox.Name = "polbox";
            this.polbox.Size = new System.Drawing.Size(463, 38);
            this.polbox.TabIndex = 24;
            // 
            // datebirthbox
            // 
            this.datebirthbox.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.datebirthbox.Location = new System.Drawing.Point(222, 156);
            this.datebirthbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.datebirthbox.Mask = "00/00/0000";
            this.datebirthbox.Name = "datebirthbox";
            this.datebirthbox.Size = new System.Drawing.Size(463, 36);
            this.datebirthbox.TabIndex = 26;
            this.datebirthbox.ValidatingType = typeof(System.DateTime);
            // 
            // numbox
            // 
            this.numbox.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numbox.Location = new System.Drawing.Point(222, 68);
            this.numbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numbox.Mask = "+9 (999) 000-00-00";
            this.numbox.Name = "numbox";
            this.numbox.Size = new System.Drawing.Size(463, 36);
            this.numbox.TabIndex = 31;
            // 
            // snilsbox
            // 
            this.snilsbox.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.snilsbox.Location = new System.Drawing.Point(222, 112);
            this.snilsbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.snilsbox.Mask = "000-000-000-00";
            this.snilsbox.Name = "snilsbox";
            this.snilsbox.Size = new System.Drawing.Size(463, 36);
            this.snilsbox.TabIndex = 32;
            // 
            // omsbox
            // 
            this.omsbox.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.omsbox.Location = new System.Drawing.Point(222, 246);
            this.omsbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.omsbox.Mask = "0000 0000 0000 0000";
            this.omsbox.Name = "omsbox";
            this.omsbox.Size = new System.Drawing.Size(463, 36);
            this.omsbox.TabIndex = 33;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(735, 449);
            this.Controls.Add(this.omsbox);
            this.Controls.Add(this.snilsbox);
            this.Controls.Add(this.numbox);
            this.Controls.Add(this.datebirthbox);
            this.Controls.Add(this.polbox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.fiobox);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Регистрация пациента";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button button1;
        private TextBox fiobox;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label7;
        private Label label8;
        private ComboBox polbox;
        private MaskedTextBox datebirthbox;
        private MaskedTextBox numbox;
        private MaskedTextBox snilsbox;
        private MaskedTextBox omsbox;
    }
}
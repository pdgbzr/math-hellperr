﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bolnica
{
    public partial class Form7 : Form
    {
        Form5 form5;
        public Form7(Form5 owner)
        {
            form5 = owner;
            InitializeComponent();
        }
        string dv;

        public void update_passing_data()
        {
            Form1.connection.Open();
            SqliteCommand command = new SqliteCommand();
            command.Connection = Form1.connection;

            if (Form5.izm == 1)
            {
                command.CommandText = "UPDATE  vrachi_date set Дата_визита = '" + datebirthbox.Text + "', Причина_обращения = '" + prichinabox.Text + "', Результат = '" + comboBox1.Text +
            "', Комментарий =  '" + textBox1.Text + "' where idz ='" + Form5.idz+"'";
                command.ExecuteNonQuery();
            }
            if (Form5.izm == 0)
            {
                command.CommandText = "INSERT INTO vrachi_date (ID,Дата_визита,Причина_обращения,Результат,Комментарий) VALUES('" + Form1.idpolzovatelya + "','" + datebirthbox.Text + "','" + prichinabox.Text + "','" + comboBox1.Text + "','" + textBox1.Text + "')";
                command.ExecuteNonQuery();
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
             
            if (datebirthbox.Text == "    -  -"|| prichinabox.Text=="" || comboBox1.Text =="")
            {
                MessageBox.Show
               (
               " Заполните все данные перед сохранением.",
               "Сообщение",
               MessageBoxButtons.OK,
               MessageBoxIcon.Information,
               MessageBoxDefaultButton.Button1
               ); ;

            }
            else
            {
                update_passing_data();
                form5.LoadData("SELECT * FROM vrachi_date where ID = '" + Form1.idpolzovatelya + "'");
                this.Close();
            }
          
        }

        private void Form7_Shown(object sender, EventArgs e)
        { if (Form5.izm == 1)
            {
                datebirthbox.Text = Form5.datepass;
                prichinabox.Text = Form6.prichina;
                comboBox1.Text = Form6.kom;
                textBox1.Text = Form5.rez;
            }
            if (Form5.izm == 3)
            {
                datebirthbox.Text = Form5.datepass;
                prichinabox.Text = Form6.prichina;
                comboBox1.Text = Form6.kom;
                textBox1.Text = Form5.rez;
                datebirthbox.ReadOnly = true;
                prichinabox.Enabled = false;
                comboBox1.Enabled = false;
                textBox1.ReadOnly = true;
                button1.Visible = false;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

            char number = e.KeyChar;
            if (e.KeyChar == 39)
            {
                e.Handled = true;
            }
            

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar == 39)
            {
                e.Handled = true;
            }
        }
    }
}
